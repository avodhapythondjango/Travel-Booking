# Deployment Instructions for Transport Drop Request System

This document outlines the steps required to deploy the Transport Drop Request System, which consists of an Angular frontend and a .NET Web API backend using SQLite as the database.

## Prerequisites

Before deploying the application, ensure that you have the following installed:

- Node.js (version 14 or higher)
- Angular CLI (version 12 or higher)
- .NET SDK (version 5.0 or higher)
- SQLite

## Deployment Steps

### 1. Clone the Repository

Clone the project repository from your version control system:

```bash
git clone <repository-url>
cd transport-drop-request-system
```

### 2. Set Up the Database

Navigate to the `database/init` directory and run the initialization script to set up the SQLite database:

```bash
cd database/init
./init-db.sh
```

### 3. Deploy the Backend (.NET Web API)

1. Navigate to the server directory:

   ```bash
   cd server/TransportDropRequest.Api
   ```

2. Restore the .NET dependencies:

   ```bash
   dotnet restore
   ```

3. Run the .NET Web API:

   ```bash
   dotnet run
   ```

   The API will be available at `http://localhost:5000/api`.

### 4. Deploy the Frontend (Angular)

1. Navigate to the client directory:

   ```bash
   cd client
   ```

2. Install the Angular dependencies:

   ```bash
   npm install
   ```

3. Start the Angular application:

   ```bash
   ng serve
   ```

   The application will be available at `http://localhost:4200`.

### 5. Access the Application

Open your web browser and navigate to `http://localhost:4200` to access the Transport Drop Request System. You can submit transport requests and manage them through the admin panel.

## Additional Configuration

- Ensure that the backend API URL is correctly set in the Angular application if you are deploying to a different environment.
- Configure CORS in the .NET Web API if the frontend and backend are hosted on different domains.

## Troubleshooting

- If you encounter issues with the database connection, check the `appsettings.json` file in the `server/TransportDropRequest.Api` directory for the correct connection string.
- Ensure that all services are running and accessible.

## Conclusion

You have successfully deployed the Transport Drop Request System. For further modifications or enhancements, refer to the documentation in the `docs` directory.