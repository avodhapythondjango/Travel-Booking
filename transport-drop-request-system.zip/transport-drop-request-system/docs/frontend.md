# Frontend Implementation for Transport Drop Request System

## Overview
The frontend of the Transport Drop Request System is built using Angular. It provides a user-friendly interface for employees to submit transport drop requests and for admins to manage these requests. The application is structured into components, services, and models to maintain a clean architecture.

## Project Structure
The Angular application is organized as follows:
- **Components**: Contains the UI components for different functionalities.
  - **Auth**: Handles user authentication (login/logout).
  - **Dashboard**: Displays an overview of the application.
  - **Request Form**: Allows users to submit new transport requests.
  - **Request List**: Displays a list of submitted requests.
  - **Admin Panel**: Provides admin functionalities to manage requests.
  
- **Services**: Contains services for API interactions and business logic.
  - **ApiService**: Handles HTTP requests to the backend API.
  - **AuthService**: Manages user authentication.
  - **NotificationService**: Provides notifications to users.

- **Models**: Defines the data structures used in the application.

## Key Features
1. **User Authentication**: Employees can log in and log out.
2. **Request Submission**: Employees can fill out a form to submit transport drop requests.
3. **Request Management**: Admins can view, update, and manage all requests.
4. **Responsive Design**: The application is designed to be responsive and user-friendly.

## Setup Instructions
1. **Install Angular CLI**: Ensure you have Angular CLI installed globally.
   ```
   npm install -g @angular/cli
   ```

2. **Clone the Repository**: Clone the project repository to your local machine.

3. **Navigate to Client Directory**: Change to the client directory.
   ```
   cd transport-drop-request-system/client
   ```

4. **Install Dependencies**: Run the following command to install all necessary dependencies.
   ```
   npm install
   ```

5. **Run the Application**: Start the Angular application using the command:
   ```
   ng serve
   ```

6. **Access the Application**: Open your browser and navigate to `http://localhost:4200` to access the application.

## Additional Notes
- Ensure that the backend API is running and accessible for the frontend to function correctly.
- The application uses reactive forms for handling user input, ensuring a smooth user experience.
- Error handling and notifications are implemented to enhance user interaction.

## Conclusion
The frontend of the Transport Drop Request System is designed to be intuitive and efficient, allowing users to easily submit and manage transport requests. The modular structure of the application promotes maintainability and scalability for future enhancements.