# API Documentation for Transport Drop Request System

## Overview
The Transport Drop Request System is a full-stack application designed to manage transport drop requests within an organization. It allows employees to submit requests for transport, which can then be managed by administrators.

## API Endpoints

### 1. Authentication

#### POST /api/auth/login
- **Description**: Authenticates a user and returns a token.
- **Request Body**:
  ```json
  {
    "username": "string",
    "password": "string"
  }
  ```
- **Response**:
  - **200 OK**: Returns a token.
  - **401 Unauthorized**: Invalid credentials.

### 2. Requests

#### POST /api/requests
- **Description**: Creates a new transport drop request.
- **Request Body**:
  ```json
  {
    "employeeName": "string",
    "dropLocation": "string"
  }
  ```
- **Response**:
  - **201 Created**: Returns the created request.
  - **400 Bad Request**: Validation errors.

#### GET /api/requests
- **Description**: Retrieves all transport drop requests.
- **Response**:
  - **200 OK**: Returns an array of requests.

#### PUT /api/requests/{id}
- **Description**: Updates an existing transport drop request.
- **Request Body**:
  ```json
  {
    "employeeName": "string",
    "dropLocation": "string"
  }
  ```
- **Response**:
  - **204 No Content**: Request updated successfully.
  - **404 Not Found**: Request with the specified ID does not exist.

### 3. Admin

#### GET /api/admin/requests
- **Description**: Retrieves all requests for admin review.
- **Response**:
  - **200 OK**: Returns an array of all requests.

#### DELETE /api/admin/requests/{id}
- **Description**: Deletes a specific transport drop request.
- **Response**:
  - **204 No Content**: Request deleted successfully.
  - **404 Not Found**: Request with the specified ID does not exist.

## Error Handling
All API responses will include an appropriate HTTP status code and a message detailing the error if applicable.

## Conclusion
This API documentation provides an overview of the endpoints available in the Transport Drop Request System. For further details on the frontend implementation and deployment, please refer to the respective documentation files.