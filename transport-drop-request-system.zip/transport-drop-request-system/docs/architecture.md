# Architecture of the Transport Drop Request System

## Overview
The Transport Drop Request System is a full-stack application designed to facilitate the management of transport drop requests within an organization. It consists of a frontend built with Angular and a backend developed using .NET Web API, with SQLite as the database for data persistence.

## Architecture Components

### 1. Frontend (Angular)
- **Framework**: Angular
- **Structure**: The frontend is structured into components, services, and models.
  - **Components**:
    - **Auth**: Handles user authentication (login/logout).
    - **Dashboard**: Displays an overview of requests and statistics.
    - **Request Form**: A reactive form for submitting new transport requests.
    - **Request List**: Displays a list of all transport requests.
    - **Admin Panel**: Allows administrators to manage requests.
  - **Services**:
    - **ApiService**: Manages HTTP requests to the backend API.
    - **AuthService**: Handles authentication logic.
    - **NotificationService**: Manages user notifications.
  - **Models**:
    - Defines the structure of data entities such as EmployeeRequest.

### 2. Backend (.NET Web API)
- **Framework**: .NET Core
- **Structure**: The backend is organized into controllers, services, models, and data access layers.
  - **Controllers**:
    - **RequestsController**: Manages API endpoints for creating, retrieving, and updating transport requests.
    - **AuthController**: Handles user authentication.
    - **AdminController**: Provides administrative functionalities.
  - **Services**:
    - **RequestService**: Contains business logic for handling transport requests.
    - **AuthService**: Manages authentication processes.
    - **EmailService**: Sends email notifications for request updates.
  - **Models**:
    - **DropRequest**: Represents the transport request entity.
    - **User**: Represents user information.
    - **AuditLog**: Logs actions performed within the system.
  - **Data Access**:
    - **ApplicationDbContext**: Manages database connections and entity configurations.

### 3. Database (SQLite)
- **Database Type**: SQLite
- **Schema**: The database schema is initialized using SQL commands defined in `init-schema.sql`. It includes tables for users, transport requests, and audit logs.

## Workflows
1. **User Authentication**: Users can log in and log out, with session management handled by the AuthService.
2. **Request Submission**: Users fill out the request form, which is validated and submitted to the backend via the ApiService.
3. **Request Management**: Admins can view, update, and manage requests through the Admin Panel.

## Deployment
The application can be deployed on any server that supports .NET Core and can serve static files for the Angular application. The database can be initialized using the provided scripts.

## Conclusion
The Transport Drop Request System is designed to streamline the process of managing transport requests within an organization, providing a user-friendly interface and robust backend services. The architecture ensures scalability and maintainability, making it suitable for future enhancements.