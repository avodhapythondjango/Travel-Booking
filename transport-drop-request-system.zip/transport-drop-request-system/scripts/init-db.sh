#!/bin/bash

# This script initializes the SQLite database for the Transport Drop Request System.

# Define the database file path
DB_FILE="database/transport_drop_request.db"

# Check if the database file already exists
if [ -f "$DB_FILE" ]; then
  echo "Database already exists. Skipping initialization."
  exit 0
fi

# Create the database file
echo "Creating database at $DB_FILE..."
sqlite3 $DB_FILE <<EOF
-- Create tables
CREATE TABLE Users (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Email TEXT NOT NULL UNIQUE
);

CREATE TABLE DropRequests (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EmployeeName TEXT NOT NULL,
    DropLocation TEXT NOT NULL,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE AuditLogs (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Action TEXT NOT NULL,
    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
EOF

echo "Database initialized successfully."