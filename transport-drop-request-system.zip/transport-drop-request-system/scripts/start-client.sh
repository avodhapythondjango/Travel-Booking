#!/bin/bash
# This script starts the Angular client application.

cd client
npm install
ng serve --open