#!/bin/bash

# Navigate to the server directory and start the .NET Web API
cd server/TransportDropRequest.Api
dotnet run