# Database Migrations README

This directory contains the migration files for the Transport Drop Request System's SQLite database. 

## Migration Overview

Migrations are used to keep the database schema in sync with the application's data models. Each migration file represents a change to the database schema, such as creating or modifying tables.

## How to Create a Migration

To create a new migration, use the following command in the terminal:

```
dotnet ef migrations add <MigrationName>
```

Replace `<MigrationName>` with a descriptive name for the migration.

## Applying Migrations

To apply the migrations to the database, run:

```
dotnet ef database update
```

This command will apply all pending migrations to the database.

## Rollback Migrations

If you need to revert a migration, you can specify the migration to roll back to:

```
dotnet ef database update <MigrationName>
```

Replace `<MigrationName>` with the name of the migration you want to revert to.

## Important Notes

- Ensure that the database connection string in `appsettings.json` is correctly configured before applying migrations.
- Always back up your database before applying or rolling back migrations to prevent data loss.