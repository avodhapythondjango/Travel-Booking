# Transport Drop Request System

## Overview
The Transport Drop Request System is a full-stack application designed to facilitate the management of transport drop requests within an organization. The application is built using Angular for the frontend, .NET Web API for the backend, and SQLite as the database.

## Features
- User authentication (login/logout)
- Request submission form for employees
- Admin panel for managing requests
- List of all transport requests with status updates
- Notifications for request status changes

## Entities
- **User**: Represents the users of the system (employees and admins).
- **DropRequest**: Represents a transport drop request submitted by an employee.
- **Transport**: Represents transport details associated with requests.
- **AuditLog**: Records actions taken on requests for tracking purposes.

## Workflows
1. **User Authentication**: Users can log in and log out of the system.
2. **Request Submission**: Employees can submit transport drop requests through a form.
3. **Request Management**: Admins can view, update, and manage all requests.
4. **Notifications**: Users receive notifications regarding the status of their requests.

## Setup Instructions

### Prerequisites
- Node.js and npm installed for the Angular client.
- .NET SDK installed for the backend.
- SQLite installed for the database.

### Running the Application

1. **Frontend (Angular)**
   - Navigate to the `client` directory:
     ```
     cd client
     ```
   - Install Angular dependencies:
     ```
     npm install
     ```
   - Start the Angular application:
     ```
     ng serve
     ```

2. **Backend (.NET Web API)**
   - Navigate to the `server` directory:
     ```
     cd server
     ```
   - Run the following command to start the .NET Web API server:
     ```
     dotnet run
     ```
   - Ensure the SQLite database is initialized by running:
     ```
     ./init-db.sh
     ```

## Additional Documentation
- [Architecture](docs/architecture.md): Overview of the application architecture.
- [API Documentation](docs/api.md): Details of the API endpoints.
- [Frontend Implementation](docs/frontend.md): Information about the frontend setup and components.
- [Deployment Instructions](docs/deployment.md): Guidelines for deploying the application.

## Final Output
The application will provide a user-friendly interface for employees to submit transport requests and for admins to manage those requests efficiently. The system will ensure that all actions are logged and that users are notified of any changes to their requests.