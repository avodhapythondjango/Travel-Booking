export interface EmployeeRequest {
  id?: string;
  employeeName: string;
  dropLocation: string;
  requestDate?: Date;
  status?: string;
}