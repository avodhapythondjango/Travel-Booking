export class AdminPanelComponent {
  requests: EmployeeRequest[] = [];

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.loadRequests();
  }

  loadRequests() {
    this.apiService.getRequests().subscribe(requests => {
      this.requests = requests;
    });
  }

  updateRequest(request: EmployeeRequest) {
    this.apiService.updateRequest(request.id, request).subscribe(() => {
      this.loadRequests();
    });
  }
}