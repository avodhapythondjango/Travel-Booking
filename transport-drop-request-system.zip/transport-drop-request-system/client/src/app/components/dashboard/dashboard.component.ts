export class DashboardComponent {
  requests: EmployeeRequest[] = [];
  
  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.loadRequests();
  }

  loadRequests() {
    this.apiService.getRequests().subscribe(data => {
      this.requests = data;
    });
  }
}