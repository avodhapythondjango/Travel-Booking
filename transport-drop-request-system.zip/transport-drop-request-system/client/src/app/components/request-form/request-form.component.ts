export class RequestFormComponent {
  requestForm: FormGroup;

  constructor(private fb: FormBuilder, private apiService: ApiService) {
    this.requestForm = this.fb.group({
      employeeName: ['', Validators.required],
      dropLocation: ['', Validators.required]
    });
  }

  onSubmit() {
    this.apiService.createRequest(this.requestForm.value).subscribe();
  }
}