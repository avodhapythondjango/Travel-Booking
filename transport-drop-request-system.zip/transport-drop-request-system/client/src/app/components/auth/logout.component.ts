export class LogoutComponent {
  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    this.logout();
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}