export class ApiService {
  constructor(private http: HttpClient) {}

  createRequest(request: EmployeeRequest): Observable<EmployeeRequest> {
    return this.http.post<EmployeeRequest>('/api/requests', request);
  }

  getRequests(): Observable<EmployeeRequest[]> {
    return this.http.get<EmployeeRequest[]>('/api/requests');
  }

  updateRequest(id: string, request: EmployeeRequest): Observable<EmployeeRequest> {
    return this.http.put<EmployeeRequest>(`/api/requests/${id}`, request);
  }
}