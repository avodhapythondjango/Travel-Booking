export class AppComponent {
  title = 'Transport Drop Request System';
}