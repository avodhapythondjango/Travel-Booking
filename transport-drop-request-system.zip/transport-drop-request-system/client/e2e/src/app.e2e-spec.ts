import { browser, by, element } from 'protractor';

describe('Transport Drop Request System', () => {
  it('should display the login page', () => {
    browser.get('/login');
    expect(element(by.css('h1')).getText()).toEqual('Login');
  });

  it('should navigate to the request form', () => {
    browser.get('/login');
    element(by.css('input[name="username"]')).sendKeys('testuser');
    element(by.css('input[name="password"]')).sendKeys('password');
    element(by.css('button[type="submit"]')).click();
    browser.get('/request-form');
    expect(element(by.css('h1')).getText()).toEqual('Request Form');
  });

  it('should submit a transport drop request', () => {
    browser.get('/request-form');
    element(by.css('input[name="employeeName"]')).sendKeys('John Doe');
    element(by.css('input[name="dropLocation"]')).sendKeys('123 Main St');
    element(by.css('button[type="submit"]')).click();
    expect(element(by.css('.notification')).getText()).toContain('Request submitted successfully');
  });

  it('should display the list of requests', () => {
    browser.get('/request-list');
    expect(element(by.css('h1')).getText()).toEqual('Request List');
    expect(element.all(by.css('table tbody tr')).count()).toBeGreaterThan(0);
  });
});