using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using TransportDropRequest.Api.Controllers;
using TransportDropRequest.Api.Models;
using TransportDropRequest.Api.Services;
using Xunit;

namespace TransportDropRequest.Api.Tests
{
    public class RequestControllerTests
    {
        private readonly Mock<RequestService> _mockRequestService;
        private readonly RequestsController _controller;

        public RequestControllerTests()
        {
            _mockRequestService = new Mock<RequestService>();
            _controller = new RequestsController(_mockRequestService.Object);
        }

        [Fact]
        public async Task CreateRequest_ReturnsCreatedRequest()
        {
            var request = new EmployeeRequest { EmployeeName = "John Doe", DropLocation = "Office" };
            _mockRequestService.Setup(service => service.CreateRequest(request)).ReturnsAsync(request);

            var result = await _controller.CreateRequest(request);

            var actionResult = Assert.IsType<ActionResult<EmployeeRequest>>(result);
            var createdResult = Assert.IsType<EmployeeRequest>(actionResult.Value);
            Assert.Equal(request.EmployeeName, createdResult.EmployeeName);
        }

        [Fact]
        public async Task GetRequests_ReturnsListOfRequests()
        {
            var requests = new List<EmployeeRequest>
            {
                new EmployeeRequest { EmployeeName = "John Doe", DropLocation = "Office" },
                new EmployeeRequest { EmployeeName = "Jane Smith", DropLocation = "Home" }
            };
            _mockRequestService.Setup(service => service.GetRequests()).ReturnsAsync(requests);

            var result = await _controller.GetRequests();

            var actionResult = Assert.IsType<ActionResult<IEnumerable<EmployeeRequest>>>(result);
            var returnedRequests = Assert.IsAssignableFrom<IEnumerable<EmployeeRequest>>(actionResult.Value);
            Assert.Equal(2, returnedRequests.Count());
        }

        [Fact]
        public async Task UpdateRequest_ReturnsNoContent()
        {
            var request = new EmployeeRequest { EmployeeName = "John Doe", DropLocation = "Office" };
            var id = "1";
            _mockRequestService.Setup(service => service.UpdateRequest(id, request)).Returns(Task.CompletedTask);

            var result = await _controller.UpdateRequest(id, request);

            Assert.IsType<NoContentResult>(result);
        }
    }
}