using System.Collections.Generic;
using System.Threading.Tasks;
using TransportDropRequest.Api.Models;

namespace TransportDropRequest.Api.Services
{
    public class TransportService
    {
        private readonly ApplicationDbContext _context;

        public TransportService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<Transport>> GetAllTransportsAsync()
        {
            return await _context.Transports.ToListAsync();
        }

        public async Task<Transport> GetTransportByIdAsync(int id)
        {
            return await _context.Transports.FindAsync(id);
        }

        public async Task<Transport> CreateTransportAsync(Transport transport)
        {
            _context.Transports.Add(transport);
            await _context.SaveChangesAsync();
            return transport;
        }

        public async Task UpdateTransportAsync(Transport transport)
        {
            _context.Entry(transport).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTransportAsync(int id)
        {
            var transport = await _context.Transports.FindAsync(id);
            if (transport != null)
            {
                _context.Transports.Remove(transport);
                await _context.SaveChangesAsync();
            }
        }
    }
}