using System.Collections.Generic;
using System.Threading.Tasks;
using TransportDropRequest.Api.Models;

namespace TransportDropRequest.Api.Services
{
    public class RequestService
    {
        private readonly ApplicationDbContext _context;

        public RequestService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<EmployeeRequest> CreateRequest(EmployeeRequest request)
        {
            _context.EmployeeRequests.Add(request);
            await _context.SaveChangesAsync();
            return request;
        }

        public async Task<IEnumerable<EmployeeRequest>> GetRequests()
        {
            return await _context.EmployeeRequests.ToListAsync();
        }

        public async Task UpdateRequest(string id, EmployeeRequest request)
        {
            var existingRequest = await _context.EmployeeRequests.FindAsync(id);
            if (existingRequest != null)
            {
                existingRequest.EmployeeName = request.EmployeeName;
                existingRequest.DropLocation = request.DropLocation;
                await _context.SaveChangesAsync();
            }
        }
    }
}