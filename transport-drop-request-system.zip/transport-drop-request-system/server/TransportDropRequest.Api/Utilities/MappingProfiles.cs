using AutoMapper;
using TransportDropRequest.Api.Models;

namespace TransportDropRequest.Api.Utilities
{
    public class MappingProfiles : Profile
    {
        public MappingProfiles()
        {
            CreateMap<DropRequest, DropRequestDto>().ReverseMap();
            CreateMap<Transport, TransportDto>().ReverseMap();
            CreateMap<User, UserDto>().ReverseMap();
        }
    }
}