using System;

namespace TransportDropRequest.Api.DTOs
{
    public class EmployeeRequestDto
    {
        public int Id { get; set; }
        public string EmployeeName { get; set; }
        public string DropLocation { get; set; }
        public DateTime RequestDate { get; set; }
    }

    public class CreateRequestDto
    {
        public string EmployeeName { get; set; }
        public string DropLocation { get; set; }
    }

    public class UpdateRequestDto
    {
        public string EmployeeName { get; set; }
        public string DropLocation { get; set; }
    }
}