using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using TransportDropRequest.Api.Models;
using TransportDropRequest.Api.Services;

namespace TransportDropRequest.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RequestsController : ControllerBase
    {
        private readonly RequestService _requestService;

        public RequestsController(RequestService requestService)
        {
            _requestService = requestService;
        }

        [HttpPost]
        public async Task<ActionResult<DropRequest>> CreateRequest(DropRequest request)
        {
            var createdRequest = await _requestService.CreateRequest(request);
            return CreatedAtAction(nameof(GetRequests), new { id = createdRequest.Id }, createdRequest);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<DropRequest>>> GetRequests()
        {
            var requests = await _requestService.GetRequests();
            return Ok(requests);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRequest(string id, DropRequest request)
        {
            await _requestService.UpdateRequest(id, request);
            return NoContent();
        }
    }
}