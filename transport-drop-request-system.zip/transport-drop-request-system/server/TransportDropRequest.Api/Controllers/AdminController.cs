using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using TransportDropRequest.Api.Models;
using TransportDropRequest.Api.Services;

namespace TransportDropRequest.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private readonly RequestService _requestService;

        public AdminController(RequestService requestService)
        {
            _requestService = requestService;
        }

        [HttpGet("requests")]
        public async Task<ActionResult<IEnumerable<EmployeeRequest>>> GetAllRequests()
        {
            return await _requestService.GetRequests();
        }

        [HttpDelete("requests/{id}")]
        public async Task<IActionResult> DeleteRequest(string id)
        {
            var result = await _requestService.DeleteRequest(id);
            if (result)
            {
                return NoContent();
            }
            return NotFound();
        }

        [HttpPut("requests/{id}")]
        public async Task<IActionResult> UpdateRequest(string id, EmployeeRequest request)
        {
            var result = await _requestService.UpdateRequest(id, request);
            if (result)
            {
                return NoContent();
            }
            return NotFound();
        }
    }
}