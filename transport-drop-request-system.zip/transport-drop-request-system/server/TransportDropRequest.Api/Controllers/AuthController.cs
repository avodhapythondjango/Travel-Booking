using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TransportDropRequest.Api.Services;
using TransportDropRequest.Api.Models;

namespace TransportDropRequest.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _authService;

        public AuthController(AuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("login")]
        public async Task<ActionResult<string>> Login([FromBody] LoginRequest loginRequest)
        {
            var token = await _authService.Login(loginRequest);
            if (token == null)
            {
                return Unauthorized();
            }
            return Ok(token);
        }

        [HttpPost("logout")]
        public IActionResult Logout()
        {
            _authService.Logout();
            return NoContent();
        }
    }
}