public class DropRequest {
    public int Id { get; set; }
    public string EmployeeName { get; set; }
    public string DropLocation { get; set; }
    public DateTime RequestDate { get; set; }
    public string Status { get; set; }
}