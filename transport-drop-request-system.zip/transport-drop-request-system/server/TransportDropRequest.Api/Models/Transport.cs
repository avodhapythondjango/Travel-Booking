public class Transport {
    public int Id { get; set; }
    public string VehicleType { get; set; }
    public string LicensePlate { get; set; }
    public string DriverName { get; set; }
    public string Status { get; set; }
}