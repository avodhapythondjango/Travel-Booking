public class ApplicationDbContext : DbContext {
  public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) {}

  public DbSet<DropRequest> DropRequests { get; set; }
  public DbSet<User> Users { get; set; }
  public DbSet<Transport> Transports { get; set; }
  public DbSet<AuditLog> AuditLogs { get; set; }

  protected override void OnModelCreating(ModelBuilder modelBuilder) {
    base.OnModelCreating(modelBuilder);
    // Additional configuration can be done here
  }
}